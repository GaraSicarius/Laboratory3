﻿using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

public class GradientPanel : Panel
{
    public Color TopColor { get; set; } = Color.FromArgb(102, 126, 234);
    public Color BottomColor { get; set; } = Color.FromArgb(118, 75, 162);

    protected override void OnPaint(PaintEventArgs e)
    {
        using (LinearGradientBrush brush = new LinearGradientBrush(
            this.ClientRectangle,
            TopColor,      // Top color
            BottomColor,   // Bottom color
            LinearGradientMode.Vertical))
        {
            e.Graphics.FillRectangle(brush, this.ClientRectangle);
        }
        base.OnPaint(e);
    }
}