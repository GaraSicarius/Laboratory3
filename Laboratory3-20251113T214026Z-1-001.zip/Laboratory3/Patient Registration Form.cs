﻿using System;
using System.Data;
using System.Windows.Forms;

namespace Laboratory3
{
    public partial class Dashboard : Form
    {
        private DataTable resultsTable;

        // This will store the row we are currently editing.
        // If it's null, we are in "Save" mode.
        // If it's not null, we are in "Update" mode.
        private DataRow currentRowBeingEdited = null;

        public Dashboard()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            InitializeResultsTable();
            PopulateTestNames(); // Fill the dropdown box

            // Bind the DataTable to the DataGridView
            dgvResults.DataSource = resultsTable;

            // Ensures the user selects the entire row
            dgvResults.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvResults.MultiSelect = false;
        }

        private void InitializeResultsTable()
        {
            resultsTable = new DataTable();
            // Replaced Patient ID with Last Name and First Name
            resultsTable.Columns.Add("Last Name", typeof(string));
            resultsTable.Columns.Add("First Name", typeof(string));
            resultsTable.Columns.Add("Test Name", typeof(string));
            resultsTable.Columns.Add("Result", typeof(string));
            resultsTable.Columns.Add("Units", typeof(string));
            resultsTable.Columns.Add("Date", typeof(DateTime));
            resultsTable.Columns.Add("Notes", typeof(string));
        }

        // A helper method to fill the Test Name dropdown
        private void PopulateTestNames()
        {
            // In a real app, you'd load this from a database.
            cboTestName.Items.Add("Complete Blood Count (CBC)");
            cboTestName.Items.Add("Basic Metabolic Panel (BMP)");
            cboTestName.Items.Add("Lipid Panel");
            cboTestName.Items.Add("Urinalysis");
            cboTestName.Items.Add("Glucose Test");
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            // 1. Validate Input
            // Updated to check new fields
            if (string.IsNullOrWhiteSpace(txtLastName.Text) ||
                string.IsNullOrWhiteSpace(txtFirstName.Text) ||
                string.IsNullOrWhiteSpace(cboTestName.Text) ||
                string.IsNullOrWhiteSpace(txtResult.Text))
            {
                MessageBox.Show("Last Name, First Name, Test Name, and Result are required fields.", "Missing Information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                // We now check if we are in "Edit" mode
                if (currentRowBeingEdited == null)
                {
                    // --- SAVE NEW RECORD ---
                    // We are creating a new record
                    resultsTable.Rows.Add(
                        txtLastName.Text,    // Added
                        txtFirstName.Text,   // Added
                        cboTestName.Text,
                        txtResult.Text,
                        txtUnits.Text,
                        dtpTestDate.Value,
                        txtNotes.Text
                    );
                }
                else
                {
                    // --- UPDATE EXISTING RECORD ---
                    // We are updating the row we selected
                    currentRowBeingEdited["Last Name"] = txtLastName.Text;   // Added
                    currentRowBeingEdited["First Name"] = txtFirstName.Text; // Added
                    currentRowBeingEdited["Test Name"] = cboTestName.Text;
                    currentRowBeingEdited["Result"] = txtResult.Text;
                    currentRowBeingEdited["Units"] = txtUnits.Text;
                    currentRowBeingEdited["Date"] = dtpTestDate.Value;
                    currentRowBeingEdited["Notes"] = txtNotes.Text;
                }

                // 3. Clear the form and reset the state
                ClearForm();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error saving data: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // This is the event handler for the Clear button
        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearForm();
        }

        // ClearForm now resets everything
        private void ClearForm()
        {
            // Updated for new fields
            txtLastName.Clear();
            txtFirstName.Clear();
            cboTestName.SelectedIndex = -1;
            cboTestName.Text = "";
            txtResult.Clear();
            txtUnits.Clear();
            txtNotes.Clear();
            dtpTestDate.Value = DateTime.Now;

            // Reset the state
            currentRowBeingEdited = null;    // Go back to "Save" mode
            btnSave.Text = "SAVE";           // Set button text back to SAVE
            dgvResults.Enabled = true;       // Re-enable the grid

            // Unlock fields
            txtLastName.ReadOnly = false;
            txtFirstName.ReadOnly = false;

            txtLastName.Focus(); // Set focus to the first field
        }

        // Event handler for the Edit button
        private void btnEdit_Click(object sender, EventArgs e)
        {
            // 1. Check if any row is selected
            if (dgvResults.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a row to edit.", "No Row Selected", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            // 2. Get the DataRow associated with the selected grid row
            DataRowView rowView = (DataRowView)dgvResults.SelectedRows[0].DataBoundItem;
            currentRowBeingEdited = rowView.Row; // SETS THE STATE

            // 3. Load the data from the row into the form fields
            // Updated for new fields
            txtLastName.Text = (string)currentRowBeingEdited["Last Name"];
            txtFirstName.Text = (string)currentRowBeingEdited["First Name"];
            cboTestName.Text = (string)currentRowBeingEdited["Test Name"];
            txtResult.Text = (string)currentRowBeingEdited["Result"];
            txtUnits.Text = (string)currentRowBeingEdited["Units"];
            dtpTestDate.Value = (DateTime)currentRowBeingEdited["Date"];
            txtNotes.Text = (string)currentRowBeingEdited["Notes"];

            // 4. Update UI to "Edit Mode"
            btnSave.Text = "UPDATE";       // Change Save button text
            dgvResults.Enabled = false;    // Disable grid to prevent changing selection

            // (Optional) Prevent changing the "key" fields
            txtLastName.ReadOnly = true;
            txtFirstName.ReadOnly = true;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            // Add a check
            if (currentRowBeingEdited != null)
            {
                MessageBox.Show("Cannot delete while editing. Please Clear or Update first.", "Action Denied", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // 1. Check if any row is selected
            if (dgvResults.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a row to delete.", "No Row Selected", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            // 2. Confirm with the user
            DialogResult confirmation = MessageBox.Show("Are you sure you want to permanently delete this record?", "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (confirmation == DialogResult.Yes)
            {
                try
                {
                    // 3. Get the underlying DataRow and remove it
                    DataRowView rowView = (DataRowView)dgvResults.SelectedRows[0].DataBoundItem;
                    rowView.Row.Delete();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error deleting data: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void lblTitle_Click(object sender, EventArgs e)
        {

        }
    }
}