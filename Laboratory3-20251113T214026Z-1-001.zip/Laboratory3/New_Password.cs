﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Laboratory3
{
    public partial class New_Password : Form
    {
        public New_Password()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // --- THIS IS THE CODE YOU NEED TO ADD ---

            // Get the text from the "new password" and "confirm password" textboxes
            string newPass = textBox1.Text;
            string confirmPass = textBox4.Text;

            // 1. Check if either textbox is empty
            if (string.IsNullOrEmpty(newPass) || string.IsNullOrEmpty(confirmPass))
            {
                MessageBox.Show("Please fill in both password fields.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return; // Stop processing
            }

            // 2. Check if the passwords match
            if (newPass == confirmPass)
            {
                // 3. If they match, show the success message
                MessageBox.Show("You Reset Your Password Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Note: In a real app, you would save the 'newPass' to your database here.
            }
            else
            {
                // 4. If they don't match, show an error message
                MessageBox.Show("Passwords do not match. Please try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            // --- END OF ADDED CODE ---
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            // Optional: You can set the password character here
            // textBox1.PasswordChar = '*';
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Create an instance of your login form
            // !! REMEMBER: Change 'Login' to the name of your login form class !!
            Login loginForm = new Login();

            // Show the login form
            loginForm.Show();

            // Close this current (New_Password) form
            this.Close();
        }
    }
}